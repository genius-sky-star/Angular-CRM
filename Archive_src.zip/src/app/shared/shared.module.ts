import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxPermissionsModule } from 'ngx-permissions';
import { HeaderComponent } from './components/header/header.component';
import { MaterialModule } from './modules/material/material.module';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DefaultModalComponent } from './components/default-modal/default-modal.component';
import { NgChartsModule } from 'ng2-charts';
import { NgxMapboxGLModule } from 'ngx-mapbox-gl';
import { environment } from 'src/environments/environment';
import { TableCommonComponent } from './components/table-common/table-common.component';
import {  MatTableModule } from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import { MatPaginatorModule } from '@angular/material/paginator';
import { HttpClientModule } from '@angular/common/http';
import { MatGridListModule } from '@angular/material/grid-list';
import { ArchiveViewDetailsComponent } from '../shared/components/archive-view-details/archive-view-details.component';
import { ArchiveActionsComponent } from '../shared/components/archive-actions/archive-actions.component';
import { WorldMapComponent } from './components/world-map/world-map.component';
import { CountSummaryComponent } from './components/count-summary/count-summary.component';
import { AnalyticHeaderComponent } from './components/analytic-header/analytic-header.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { TimeFilterComponent } from './components/time-filter/time-filter.component';
import { DoughnutChartComponent } from './components/doughnut-chart/doughnut-chart.component';
import { TrendAnalyticsComponent } from './components/trend-analytics/trend-analytics.component';
import { TokenAnalyticsComponent } from './components/token-analytics/token-analytics.component';
import { EstimateAnalysisComponent } from './components/estimate-analysis/estimate-analysis.component';
import { OverviewAnalysisComponent } from './components/overview-analysis/overview-analysis.component';
import { ViewWithSidebarComponent } from './components/view-with-sidebar/view-with-sidebar.component';
import { VideoPlayerComponent } from './components/video-player/video-player.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatNativeDateModule } from '@angular/material/core';

@NgModule({
  declarations: [
    HeaderComponent,
    DefaultModalComponent,
    TableCommonComponent,
    ArchiveViewDetailsComponent, 
    ArchiveActionsComponent,
    WorldMapComponent,
    CountSummaryComponent,
    AnalyticHeaderComponent,
    LineChartComponent,
    BarChartComponent,
    TimeFilterComponent,
    DoughnutChartComponent,
    TrendAnalyticsComponent,
    TokenAnalyticsComponent,
    EstimateAnalysisComponent,
    OverviewAnalysisComponent,
    ViewWithSidebarComponent,
    VideoPlayerComponent,
  ],
  imports: [
    CommonModule,
    FormsModule ,
    HttpClientModule,
    NgxPermissionsModule,
    FontAwesomeModule,
    MatTableModule,
    MatSortModule,
    RouterModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    NgChartsModule,
    MatPaginatorModule,
    HttpClientModule,
    NgxMapboxGLModule.withConfig({
      accessToken: environment.mapboxKey,
    }),
    HttpClientModule,
    MatGridListModule,
    MatDatepickerModule,
    MatInputModule,
    MatFormFieldModule,
    MatNativeDateModule
  ],
  exports: [
    HeaderComponent,
    DefaultModalComponent,
    TableCommonComponent,
    WorldMapComponent,
    CountSummaryComponent,
    AnalyticHeaderComponent,
    LineChartComponent,
    BarChartComponent,
    TimeFilterComponent,
    DoughnutChartComponent,
    TrendAnalyticsComponent,
    TokenAnalyticsComponent,
    EstimateAnalysisComponent,
    OverviewAnalysisComponent,
    HeaderComponent,
    FontAwesomeModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    NgChartsModule,
    NgxMapboxGLModule,
    MatPaginatorModule,
    TableCommonComponent,
    HttpClientModule,
    MatGridListModule,
    ViewWithSidebarComponent,
    HttpClientModule,
    MatDatepickerModule,
    MatInputModule,
    MatFormFieldModule,
    MatNativeDateModule
  ]
})
export class SharedModule {}
