import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap, catchError, throwError, map } from 'rxjs';
import { environment } from 'src/environments/environment';
import { LoadingService } from '../loading/loading.service';
import { ApiService } from '../api/api.service';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  private readonly baseURL = environment.apiUrl;

  constructor(
    private http: HttpClient, 
    private loadingService: LoadingService,
    private apiService: ApiService
    ) { }

  getUserList() {
    return this.apiService.get('/admin/user').subscribe(async data => {

    })
    // if(error || !data?.session) {
    //   this.eventQueueService.dispatch(new AppEvent(AppEventType.SESSION_EXPIRED, error));
    //   return Promise.reject<AuthError>(error);
    // } else {
    //   this.eventQueueService.dispatch(new AppEvent(AppEventType.SESSION_VALID, data.session));
    //   return Promise.resolve<User>(data.session.user);
    // }
  }
  
}
