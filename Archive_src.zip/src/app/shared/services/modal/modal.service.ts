import { ComponentType } from '@angular/cdk/portal';
import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DefaultModalComponent } from '../../components/default-modal/default-modal.component';

@Injectable({
  providedIn: 'root'
})
export class ModalService {

  constructor(private dialog: MatDialog) { }

  create(config: {
    type?: 'success' | 'error' | 'info',
    iconPath?: string,
    message?: string,
    title?: string,
    subMessage?: string,
    buttons?: { text: string, handler: (evt: any) => boolean | undefined }[],
    component?: ComponentType<DefaultModalComponent>
  }) {
    let component = config.component || DefaultModalComponent;
    if (!config.message && !config.component) {
      throw new Error('Either a message or Dialog component is required');
    }

    const { type, iconPath, message, title, subMessage, buttons } = config;
    const data = {
      type,
      iconPath,
      message,
      title,
      subMessage,
      buttons
    };
    return this.dialog.open(component, { data,
      panelClass:'custom-modalbox' 
    });
  }
}
