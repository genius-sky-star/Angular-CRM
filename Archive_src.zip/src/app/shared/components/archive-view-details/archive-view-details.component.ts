import { AfterViewInit, Component, ViewChild, Inject } from '@angular/core';
import { MatDialogRef, MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

export interface PeriodicElement {
  userName: string;
  joinedTime: string;
}

@Component({
  selector: 'app-archive-view-details',
  templateUrl: './archive-view-details.component.html',
  styleUrls: ['./archive-view-details.component.scss']
})
export class ArchiveViewDetailsComponent {
  displayedColumns: Array<string> = [];
  dataSource = new MatTableDataSource<PeriodicElement>([]);
  viewersData: any = [];
  @ViewChild('paginator') paginator: MatPaginator;

  constructor(
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<ArchiveViewDetailsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      action: string
      viewerData: string
    }
  ) {
    console.log('data: ', this.data);
    this.displayedColumns = ['userName', 'joinedTime'];
    this.viewersData = [
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' },
      { userName: 'Ashley Kent', joinedTime: '11:02:32' }
    ];
  }

  ngAfterViewInit() {
    this.dataSource = new MatTableDataSource<PeriodicElement>(this.viewersData);
    this.dataSource.paginator = this.paginator;
  }

  closeDialog() {
    this.dialogRef.close();
  }

}
