import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArchiveViewDetailsComponent } from './archive-view-details.component';

describe('ArchiveViewDetailsComponent', () => {
  let component: ArchiveViewDetailsComponent;
  let fixture: ComponentFixture<ArchiveViewDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArchiveViewDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ArchiveViewDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
