import { Component, Inject } from '@angular/core';
import { MatDialogRef, MatDialog, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-video-player',
  templateUrl: './video-player.component.html',
  styleUrls: ['./video-player.component.scss']
})
export class VideoPlayerComponent {
  videoUrl: string = "";
  videoTitle: string = "";
  constructor(
    private dialog: MatDialog,
    private dialogRef: MatDialogRef<VideoPlayerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: {
      data: any
    }) {
    console.log('videoData: ', this.data);
    this.videoUrl = this.data['videoUrl'];
    this.videoTitle = this.data['title'];
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
