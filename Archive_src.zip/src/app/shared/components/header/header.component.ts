import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { EventQueueService } from '../../services/event-queue/event-queue.service';
import { AppEventType } from '../../enums/app-event-type.enum';
import { AuthService } from '../../services/auth/auth.service';
import { AppEvent } from '../../types/events/app-event.type';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  isMenuOpened: boolean = false;
  isLoggedIn: boolean = false;
  userHeader : boolean = false;
  selectedType : string = 'all';
  tabs : string[] = ['Members','Streamers','Featured Models','Physical Goods','User Stats','User Permissions'];
  archiveHeader: boolean = false;
  archiveHeaderType = 'liveThumbnail';

  constructor(
    private authService: AuthService, 
    private eventQueueService: EventQueueService, 
    private cd: ChangeDetectorRef,
    private router: Router) {}

  ngOnInit(): void {
    this.initializeHeader();
  }



  private initializeHeader() {
    this.eventQueueService.on(AppEventType.SESSION_VALID)
    .subscribe(() => {
      console.log('User is logged in');
      this.isLoggedIn = true;
      this.cd.detectChanges();
    });

    this.eventQueueService.on(AppEventType.LOGIN_SUCCESS)
    .subscribe(() => {
      console.log('User is logged in');
      this.isLoggedIn = true;
      this.cd.detectChanges();
    });

    this.eventQueueService.on(AppEventType.LOGOUT_SUCCESS)
    .subscribe(() => {
      console.log('User is logged out');
      this.isLoggedIn = false;
      this.cd.detectChanges();
    });

    this.eventQueueService.on(AppEventType.SESSION_EXPIRED)
    .subscribe(() => {
      console.log('User is logged out');
      this.isLoggedIn = false;
      this.cd.detectChanges();
    });

    this.eventQueueService.on(AppEventType.ARCHIVE_PAGE)
    .subscribe(() => {
      console.log('Archive page');
      this.userHeader = false;
      this.archiveHeader = true;
      this.cd.detectChanges();
    });
  }

  filterUsers(type){
    this.selectedType = type;
    this.archiveHeaderType = type;
    this.eventQueueService.dispatch(new AppEvent(AppEventType.USER_TYPE, type));
  }

  logout() {
    this.authService.signOut();
  }
}
