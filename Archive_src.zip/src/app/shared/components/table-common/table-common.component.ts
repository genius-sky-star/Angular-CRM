import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { MatSort, Sort } from '@angular/material/sort';
import {  MatTableDataSource } from '@angular/material/table';
import { Column } from '../../interfaces/column';
import { G3UserTypeEnum } from 'src/app/shared/enums/app-event-type.enum'

export interface UserFilter {
  name:string;
  options:string[];
  defaultValue:string;
}

@Component({
  selector: 'app-table-common',
  templateUrl: './table-common.component.html',
  styleUrls: ['./table-common.component.scss']
})
export class TableCommonComponent implements OnInit {

  @ViewChild(MatSort) sort: MatSort ;
  @ViewChild(MatPaginator) paginatior !: MatPaginator;
  @Output() onViewRecording: EventEmitter<any> = new EventEmitter();
  @Output() onDeleteRecording: EventEmitter<any> = new EventEmitter();
  

  @Input()
  tableColumns: Array<Column> = [];

  displayedColumns: Array<string> = [];
  dataSource  = new MatTableDataSource();
  //  @Input() tableData: any;
   _tableData: any;
  @Input() 
  set tableData(v) {
    this._tableData = v;
    this.init();

  }
  get tableData() {
    return this._tableData;
  }
  @Input() columnHeader: any = [];
  @Input() isUserTable: Boolean = false;
  @Input() isArchiveTable: Boolean = false;
  

  @Input() tableHeaderBackgroundColor : string | undefined;
  @Input() matheadercolor : string | undefined;
  objectKeys = Object.keys;
  archiveRecordingdataSource = new MatTableDataSource();
  sortedDataSource = new MatTableDataSource();
  dataSourceFilters = new MatTableDataSource();
  @ViewChild('paginator') paginator: MatPaginator;
  userType: string[]=['All','Banned','Suspended'];
  roleType: string[]=['Member','Streamer','Admin'];
  defaultValue = "All";
  defaultRole : string = "Member";
  sortNumber: number;
  userFilters: UserFilter[]=[];
  filterDictionary= new Map<string,string>();

  _selectedUserType: string;
  @Input() 
  set selectedUserType(v) {
    this._selectedUserType = v;
    // execute your update code
    if(!this.isArchiveTable){
      this.filterDictionary.clear();
      this.applyEmpFilter(this._selectedUserType,{name:'Type',options:this._selectedUserType,defaultValue:this.defaultValue});
      this.defaultRole = "Member";
      this.applyEmpFilter(this.defaultRole,{name:'role',options:this.roleType,defaultValue:this.defaultRole});
    }
   

  }
  get selectedUserType() {
    return this._selectedUserType;
  }

  _searchText: string;
  @Input() 
  set searchText(v) {
    this._searchText = v;
    console.log("Sarch text ",  v);
    this.dataSourceFilters.filter = this._searchText.trim().toLowerCase(); 
  }
  get searchText() {
    return this._searchText;
  }
  constructor(){
  }

  ngOnInit() {
    if(this.isUserTable){
      if(!this.searchText) this.init();
    } else if(this.isArchiveTable) {
      this.displayedColumns = this.columnHeader.map((c) => c);
      this.dataSource = new MatTableDataSource(this.tableData);
      this.dataSource.paginator = this.paginator;
    } else {
      this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
      this.dataSource = new MatTableDataSource(this.tableData);
      this.dataSource.sort = this.sort ;
      this.dataSource.paginator = this.paginatior;
    }
  }

  init(){
    
    this.displayedColumns = this.tableColumns.map((c) => c.columnDef);
    this.dataSourceFilters = new MatTableDataSource(this.tableData);
    // this.dataSourceFilters.filter = this.defaultRole.trim();
    // console.log('dataSourceFilters: ', this.dataSourceFilters.filteredData);
    this.dataSourceFilters.sort = this.sort;
    this.sortedDataSource.data = this.dataSourceFilters.data.slice();
   
    this.userFilters = [];
    this.userFilters.push({name:'Type',options:this.userType,defaultValue:this.defaultValue});
    this.userFilters.push({name:'role',options:this.roleType,defaultValue:this.defaultRole});
    let self = this;
    this.dataSourceFilters.filterPredicate = function (record,filter) {
      if(self.isJsonString(filter)){
        var map = new Map(JSON.parse(filter));
        let isMatch = false;
        for(let [key,value] of map){
          isMatch = (value=="All") || (record['Status'] == value) || (record['role'] == value); 
          if(!isMatch) return false;
        }
        return isMatch;
      }else {
        return record['FullName'].toLowerCase().includes(filter.toLowerCase()); 
      }
    }
    console.log('dataSourceFilters: ', this.dataSourceFilters.filteredData);
  }

  isJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
  }

  applyEmpFilter(ob:any,userFilters:any) {

    this.filterDictionary.set(userFilters.name,ob.value || ob);


    var jsonString = JSON.stringify(Array.from(this.filterDictionary.entries()));
    
    this.dataSourceFilters.filter = jsonString;
    //console.log(this.filterValues);
  }

  ngAfterViewInit() {
    this.dataSourceFilters.paginator = this.paginator;
    this.dataSource.paginator = this.paginatior;
  }


  sortData(sort: Sort) {
    const data = [...this.dataSource.data];
    if (!sort.active || sort.direction === '') {
      this.dataSource.data = data;
      return;
    }

    const sortedData = data.sort((a, b) => {
      console.log("sort.direction",sort.direction);
      
      const isAsc = sort.direction === 'asc';
      
      const activeColumn = sort.active;
      return isAsc ? a[activeColumn].localeCompare(b[activeColumn]) : b[activeColumn].localeCompare(a[activeColumn]);
    });

    this.dataSource.data = sortedData;
  }

  filterUsers(type) {
    this.defaultRole = type;
    // this.dataSourceFilters.filter = this.defaultRole.toString().trim();
    // console.log('dataSourceFilters: ', this.dataSourceFilters.filteredData);
    this.filterDictionary.set('role',type);
    this.applyEmpFilter(type, {'name':'role', 'value':type })
    // this.filterDictionary.clear();
    // this.applyEmpFilter(type,{name:'userType'});
  }

  filterClick(event) {
    console.log(event)
    let element: HTMLElement = document.getElementById("filterSelect") as HTMLElement;
    element.click();
  }

  viewRecording(data) {
    this.onViewRecording.emit(data);
  }

  deleteRecording(data){
    this.onDeleteRecording.emit(data);
  }

}