import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-count-summary',
  templateUrl: './count-summary.component.html',
  styleUrls: ['./count-summary.component.scss']
})
export class CountSummaryComponent {

  @Input() title = 'Not available';
  @Input() count: number | string = 0;
  @Input() direction: 'up' | 'down' | undefined;
  @Input() titleStyle : string;
}
