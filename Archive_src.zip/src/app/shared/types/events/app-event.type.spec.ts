import { AppEventType } from './app-event.type';

describe('AppEventType', () => {
  it('should create an instance', () => {
    expect(new AppEventType()).toBeTruthy();
  });
});
