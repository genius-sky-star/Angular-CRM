import { Component } from '@angular/core';
import { Form, FormBuilder, FormControl, FormGroup, UntypedFormControl, Validators } from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { AdminService } from '../services/admin.service';
import { emptyObjectValidator } from 'src/app/shared/validators/general.validators';
import { Column } from 'src/app/shared/interfaces/column';
import { Role } from '../../types/role.interface';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.scss']
})
export class RolesComponent {

  readonly separatorKeysCodes = [ENTER, COMMA] as const;
  sidenavOpened: boolean = false;
  roleForm!: FormGroup;
  permissionsList = [];
  adminForm: FormGroup<{ email: FormControl<string>; role: FormControl<{ name: string; value: any; }>; }>;
  rolesList: { name: string; value: any; }[] = [];
  rolesCreate: boolean;
  rolesTableColumns: Array<Column> = [
    {
      columnDef: 'Name',
      header: 'Name',
      cell: (element: Record<string, any>) => `${element['StreamerTag']}`,
      image : 'active-streams.png',
      isImage : true
    },
    {
      columnDef: 'Description',
      header: 'Description',
      cell: (element: Record<string, any>) => `${element['StreamTitle']}`,
    },
    // {
    //   columnDef: 'startTime',
    //   header: 'Start Time',
    //   cell: (element: Record<string, any>) => `${element['startTime']}`
    // },
    // {
    //   columnDef: 'startDate',
    //   header: 'Start Date',
    //   cell: (element: Record<string, any>) => `${element['startDate']}`
    // },
    // {
    //   columnDef: 'walletBalance',
    //   header: 'Wallet Balance',
    //   cell: (element: Record<string, any>) => `${element['walletBalance']}`,
    //   image : 'active-streams.png',
    //   isNumberAndImage : true,
    // }
  ];

  adminsTableColumns: Array<Column> = [
    {
      columnDef: 'Name',
      header: 'Name',
      cell: (element: Record<string, any>) => `${element['StreamerTag']}`,
      image : 'active-streams.png',
      isImage : true
    },
    {
      columnDef: 'Email',
      header: 'Email',
      cell: (element: Record<string, any>) => `${element['StreamTitle']}`,
    },
    {
      columnDef: 'Role',
      header: 'Role',
      cell: (element: Record<string, any>) => `${element['StreamTitle']}`,
    },
  ];

  rolesDataSource: Role[] = [];
  adminsDataSource: Role[] = [];
  adminsFilterString = '';
  rolesFilterString = '';


  constructor(private fb: FormBuilder, private readonly adminService: AdminService) {

    this.initializeRoleForm();
    this.initializeAdminForm();
  }

  initializeRoleForm(roleData?: any) {
    this.roleForm = this.fb.group({
      roleName: new FormControl('', [Validators.required]),
      roleDescription: new FormControl('', [Validators.required]),
      permissions: new FormControl(null, [Validators.required, , emptyObjectValidator()])
    });
    this.adminService.getPermissions()
    .subscribe(result => {
      console.log(result)
      this.permissionsList = Object.keys(result).map(key => {
        console.log(key, {name: key, value: result[key]})
        return {name: key, value: result[key]};
      });
      console.log(this.permissionsList);
    })
  }

  initializeAdminForm(adminData?: any) {
    this.adminForm = this.fb.group({
      email: new FormControl('', [Validators.required]),
      role: new FormControl(null, [Validators.required]), // TODO: Update for prepopulated form
    });
    this.adminService.getRoles()
    .subscribe(result => {
      console.log(result)
      this.rolesList = Object.keys(result).map(key => {
        console.log(key, {name: result[key]['name'], value: result[key]['id']})
        return {name: result[key]['name'], value: result[key]['id']};
      });
      console.log(this.rolesList);
    })
  }

  openEditPanel() {
    this.roleForm.reset();
    this.initializeRoleForm();
    this.rolesCreate = true;
    this.sidenavOpened = true;
  }

  openAdminCreatePanel() {
    this.adminForm.reset();
    this.initializeAdminForm();
    this.rolesCreate = false;
    this.sidenavOpened = true;
  }

  createRole() {
    debugger;
    if(this.roleForm.valid) {
      const {roleName, roleDescription, permissions} = this.roleForm.value; // TODO: Type properly
      const payload = {
        permissions: permissions.map(p => p.value),
        name: roleName,
        description: roleDescription,
      };
      this.adminService.createRole(payload)
      .subscribe(res => {
        this.sidenavOpened = false;
      })
    }
  }

  createAdmin() {
    debugger;
    if(this.adminForm.valid) {
      const {email, role} = this.adminForm.value;
      debugger;
      const payload = {
        role: role?.[0].value,
        email: `${email}@girlsgonegame.com`,
      };
      this.adminService.createAdmin(payload)
      .subscribe(res => {
        this.sidenavOpened = false;
      })
    }
  }
}
