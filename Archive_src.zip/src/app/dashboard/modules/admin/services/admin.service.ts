import { Injectable } from '@angular/core';
import { map, tap } from 'rxjs';
import { ApiService } from 'src/app/shared/services/api/api.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private readonly apiService: ApiService) { }

  createRole(payload) { // TODO: Type properly
    return this.apiService.post<{[key: string]: string}>('/roles', payload)
    .pipe(map(res => {
      console.log(res);
      return res['data'];
    }));
  }

  createAdmin(payload) {// TODO: Type properly
    return this.apiService.post<{[key: string]: string}>('/admin', payload)
    .pipe(map(res => {
      console.log(res);
      return res['data'];
    }));
  }

  getPermissions() {
    return this.apiService.get<{[key: string]: string}>('/roles/permissions')
    .pipe(map(res => {
      console.log(res);
      return res['data'];
    }));
  }

  getRoles() {
    return this.apiService.get<{[key: string]: string}>('/roles')
    .pipe(map(res => {
      console.log(res);
      return res['data'];
    }));
  }

  updateRole(payload)  {// TODO: Type properly
    return this.apiService.patch<{[key: string]: string}>('/admin', payload)
    .pipe(map(res => {
      console.log(res);
      return res['data'];
    }));
  }
}
