import { ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { ArchiveViewDetailsComponent } from '../../../shared/components/archive-view-details/archive-view-details.component';
import { ArchiveActionsComponent } from '../../../shared/components/archive-actions/archive-actions.component';
import { merge, of } from 'rxjs';
import { startWith, switchMap } from 'rxjs/operators';
import { AppEventType } from 'src/app/shared/enums/app-event-type.enum';
import { EventQueueService } from 'src/app/shared/services/event-queue/event-queue.service';
import { VideoPlayerComponent } from '../../../shared/components/video-player/video-player.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { NgFor } from '@angular/common';
import { MatSelectModule } from '@angular/material/select';
import {MatTableDataSource, MatTableModule} from '@angular/material/table';
import { AppEvent } from 'src/app/shared/types/events/app-event.type';

export interface PeriodicElement {
  userData: any;
  date: string;
  message: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {userData: {name: 'Hydrogen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Helium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Lithium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Beryllium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Be'},
  {userData: {name: 'Boron', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Carbon', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Nitrogen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Oxygen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Fluorine', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Neon', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Sodium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Magnesium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Aluminum', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi There'},
  {userData: {name: 'Hydrogen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Helium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Lithium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Beryllium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Be'},
  {userData: {name: 'Boron', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Carbon', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Nitrogen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Oxygen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Fluorine', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Neon', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Sodium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Magnesium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Aluminum', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi There'},
  {userData: {name: 'Hydrogen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Helium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Lithium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Beryllium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Be'},
  {userData: {name: 'Boron', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Carbon', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Nitrogen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Oxygen', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Fluorine', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Neon', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi there'},
  {userData: {name: 'Sodium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {userData: {name: 'Magnesium', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {userData: {name: 'Aluminum', email: 'aliciaVikander@mail.com'}, date: '28-05-23', message: 'Hi There'},
];

const chatData = [
  {time: '22:48', name: 'Hydrogen', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Helium', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Lithium', message: 'Hi there'},
  {time: '22:48', name: 'Beryllium', message: 'Be'},
  {time: '22:48', name: 'Boron', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Carbon', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Nitrogen', message: 'Hi there'},
  {time: '22:48', name: 'Oxygen', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Fluorine', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Neon', message: 'Hi there'},
  {time: '22:48', name: 'Sodium', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Magnesium', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Aluminum', message: 'Hi There'},
  {time: '22:48', name: 'Hydrogen', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Helium', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Lithium', message: 'Hi there'},
  {time: '22:48', name: 'Beryllium', message: 'Be'},
  {time: '22:48', name: 'Boron', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Carbon', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Nitrogen', message: 'Hi there'},
  {time: '22:48', name: 'Oxygen', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Fluorine', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Neon', message: 'Hi there'},
  {time: '22:48', name: 'Sodium', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Magnesium', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Aluminum', message: 'Hi There'},
  {time: '22:48', name: 'Hydrogen', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Helium', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Lithium', message: 'Hi there'},
  {time: '22:48', name: 'Beryllium', message: 'Be'},
  {time: '22:48', name: 'Boron', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Carbon', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Nitrogen', message: 'Hi there'},
  {time: '22:48', name: 'Oxygen', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Fluorine', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Neon', message: 'Hi there'},
  {time: '22:48', name: 'Sodium', message: 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Et, minus.'},
  {time: '22:48', name: 'Magnesium', message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique aperiam vero dolore minus hic corrupti voluptatem necessitatibus officia earum! Maiores!'},
  {time: '22:48', name: 'Aluminum', message: 'Hi There'},
];

@Component({
  selector: 'app-archives',
  templateUrl: './archives.component.html',
  styleUrls: ['./archives.component.scss']
})
export class ArchivesComponent {
  thumbnailTableData = [
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "GTA Live stream",
      "date": "31 Aug, 2023",
      "duration": "02h:45m:20s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Call of duty Live stream",
      "date": "29 Aug, 2023",
      "duration": "10h:05m:35s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Ashphalt Live stream",
      "date": "23 Jul, 2023",
      "duration": "12h:23m:33s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Mafia Wars Live stream",
      "date": "09 Jul, 2023",
      "duration": "17h:55m:22s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "GTA Live stream",
      "date": "31 Aug, 2023",
      "duration": "02h:45m:20s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Call of duty Live stream",
      "date": "29 Aug, 2023",
      "duration": "10h:05m:35s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Ashphalt Live stream",
      "date": "23 Jul, 2023",
      "duration": "12h:23m:33s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Mafia Wars Live stream",
      "date": "09 Jul, 2023",
      "duration": "17h:55m:22s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "GTA Live stream",
      "date": "31 Aug, 2023",
      "duration": "02h:45m:20s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Call of duty Live stream",
      "date": "29 Aug, 2023",
      "duration": "10h:05m:35s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Ashphalt Live stream",
      "date": "23 Jul, 2023",
      "duration": "12h:23m:33s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Mafia Wars Live stream",
      "date": "09 Jul, 2023",
      "duration": "17h:55m:22s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "GTA Live stream",
      "date": "31 Aug, 2023",
      "duration": "02h:45m:20s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Call of duty Live stream",
      "date": "29 Aug, 2023",
      "duration": "10h:05m:35s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Ashphalt Live stream",
      "date": "23 Jul, 2023",
      "duration": "12h:23m:33s"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "videoUrl": "http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      "title": "Mafia Wars Live stream",
      "date": "09 Jul, 2023",
      "duration": "17h:55m:22s"
    },
  ]
  @ViewChild(MatPaginator) paginator: MatPaginator;
  allUser : any = [
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Admin",
      "source": "Floxy Nina - GRWM Cam Special 1"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special 2"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Admin",
      "source": "Floxy Nina - GRWM Cam Special 3"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special 4"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Admin",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special 5"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special 6"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Admin",
      "source": "Floxy Nina - GRWM Cam Special 7"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image.jpeg",
      "userType": "Streamer",
      "source": "Floxy Nina - GRWM Cam Special 8"
    },
    {
      "imgUrl": "../../../../assets/images/admin_image_2.jpeg",
      "userType": "Admin",
      "source": "Floxy Nina - GRWM Cam Special 9"
    },
  ]
  lowValue: number = 0;
  highValue: number = 20;
  length: number = 0;
  pageSize: number = 6;
  pagedList: any = [];
  headerType = "liveThumbnail";
  searchText: string = "";
  archiveColumns: string[] = ['imgUrl', 'title', 'date', 'duration', 'btn'];
  userTypes = ['User', 'Admin', 'Streamer'];
  userType: any;
  chatDate: any;
  searchValue: any;
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);
  displayedColumns: string[] = ['userData', 'date', 'message', 'btn'];
  chatData: boolean = false;
  chatsList: any = [];

  public getPaginatorData(event: PageEvent) {
    let startIndex = event.pageIndex * event.pageSize;
    let endIndex = startIndex + event.pageSize;
    if(endIndex > this.length){
      endIndex = this.length;
    }
    this.pagedList = this.allUser.slice(startIndex, endIndex);
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  constructor(
    private dialog: MatDialog,
    private eventQueueService: EventQueueService,
    private cd: ChangeDetectorRef
  ) {
  }

  ngOnInit() {
    this.eventQueueService.dispatch(new AppEvent(AppEventType.ARCHIVE_PAGE, true));
    this.eventQueueService.on(AppEventType.USER_TYPE)
    .subscribe((type : any) => {
      this.headerType = type.payload;
      console.log('headerType: ', this.headerType)
    })
    this.pagedList = this.allUser.slice(0, this.pageSize);
    this.length = this.allUser.length;
  }

  async archiveView(viewerData) {
    const data = {
      viewerData: viewerData
    }
    const dialogRef = await this.dialog.open(ArchiveViewDetailsComponent, {data
    });

    let dialogSubscription = dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      dialogSubscription.unsubscribe();
      if (result) {
        // this.uploadFileToFirebase(base64, result.fileName ? result.fileName : 'output');
      }
    });
  }
  
  async archiveAction(viewerData, action) {
    const data = {
      action: action,
      viewerData: viewerData
    }
    const dialogRef = await this.dialog.open(ArchiveActionsComponent, { data
    });

    let dialogSubscription = dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      dialogSubscription.unsubscribe();
      if (result) {
        // this.uploadFileToFirebase(base64, result.fileName ? result.fileName : 'output');
      }
    });
  }

  doFilter(val){
    this.searchText = val.target.value;
    this.cd.detectChanges();
  }

  async openVideoPlayer(data) {
    console.log("videoUrl: ", data.videoUrl);
    const dialogRef = await this.dialog.open(VideoPlayerComponent, { data, panelClass: 'video-player'
    });

    let dialogSubscription = dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
      dialogSubscription.unsubscribe();
      if (result) {
        // this.uploadFileToFirebase(base64, result.fileName ? result.fileName : 'output');
      }
    });
  }

  searchValueChange(event) {
    console.log('searchValue: ', this.searchValue);
    if (event.target.value.length > 3) {
      this.searchValue = event.target.value;
      console.log('searchValue: ', this.searchValue);
    }
  }

  userTypeChange(event) {
    console.log('userType: ', this.userType);
    
  }

  searchChat(event) {
    console.log('searchFilter:', this.chatDate);
    console.log('searchFilter:', this.userType);
    console.log('searchFilter:', this.searchValue);
    this.chatsList = []
    this.chatData = true;
  }

  chatDateChange(event) {
    this.chatDate = new Date(event.value).getDate() + '-'+new Date(event.value).getMonth() + '-' + new Date(event.value).getFullYear();
    console.log('chatDate: ', this.chatDate);
  }

  viewMessage(messageData) {
    console.log('messageData: ', messageData);
    this.chatData = false;
    this.chatsList = chatData;
  }

}
