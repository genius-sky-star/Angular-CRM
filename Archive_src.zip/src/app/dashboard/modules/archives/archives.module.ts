import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ArchivesRoutingModule } from './archives-routing.module';
import { ArchivesComponent } from './archives.component';
import { SharedModule } from 'src/app/shared/shared.module';


@NgModule({
  declarations: [
    ArchivesComponent
  ],
  imports: [
    CommonModule,
    ArchivesRoutingModule,
    SharedModule
  ]
})
export class ArchivesModule { }
