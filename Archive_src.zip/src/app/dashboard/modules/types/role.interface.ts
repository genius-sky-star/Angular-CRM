export interface Role {

}
