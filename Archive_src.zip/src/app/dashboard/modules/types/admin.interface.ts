export interface Admin {

}
