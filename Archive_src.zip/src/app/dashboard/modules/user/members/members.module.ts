import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MembersRoutingModule } from './members-routing.module';
import { MembersComponent } from './members.component';
import { TotalMembersComponent } from './total-members/total-members.component';
import { SharedModule } from 'src/app/shared/shared.module';



@NgModule({
  declarations: [
    MembersComponent,
    TotalMembersComponent
  ],
  imports: [
    SharedModule,
    CommonModule,
    MembersRoutingModule,
  ]
})
export class MembersModule { }
