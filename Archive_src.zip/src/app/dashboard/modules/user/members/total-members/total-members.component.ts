import { Component } from '@angular/core';
import { Column } from 'src/app/shared/interfaces/column';

export interface Member{
  Image:string;
  Rank:string;
  Username:string;
  Tokens:number;
  Email:string;
  Created:string;
}

const TOTAL_MEMBERS_DATA :Member[] = [
  { Image:'member_avatar.svg',Username: 'Alicia Stevens',Rank : '1st', Tokens: 10986, Email: 'aliciasteve@exam.com', Created: '11 Aug 2023'},
  { Image:'member_avatar.svg',Username: 'Alicia Stevens',Rank : '1st', Tokens: 10986, Email: 'aliciasteve@exam.com', Created: '11 Aug 2023'},  
  { Image:'member_avatar.svg',Username: 'Alicia Stevens',Rank : '1st', Tokens: 10986, Email: 'aliciasteve@exam.com', Created: '11 Aug 2023'},
  { Image:'member_avatar.svg',Username: 'Alicia Stevens',Rank : '1st', Tokens: 10986, Email: 'aliciasteve@exam.com', Created: '11 Aug 2023'},
  { Image:'member_avatar.svg',Username: 'Alicia Stevens',Rank : '1st', Tokens: 10986, Email: 'aliciasteve@exam.com', Created: '11 Aug 2023'},
];
@Component({
  selector: 'app-total-members',
  templateUrl: './total-members.component.html',
  styleUrls: ['./total-members.component.scss']
})
export class TotalMembersComponent {

  readonly selected : string ='month';

  readonly totalMembersCountData = [
    {
      title: 'Total Members',
      count: '43.5',
      direction: 'up' as any
    },{
      title: 'Current Online Members',
      count: '43.5',
      direction: 'down'
    },{
      title: 'New Members',
      count: '43.5',
      direction: 'down'
    },
  ];

  TotalMembersData  = TOTAL_MEMBERS_DATA ;


  tableColumns: Array<Column> = [
    {
      columnDef: 'Username',
      header: 'User Name',
      cell: (element: Record<string, any>) => `${element['Username']}`,
      image : 'member_avatar.svg',
      isImage : true
    },
    {
      columnDef: 'Rank',
      header: 'Rank',
      cell: (element: Record<string, any>) => `${element['Rank']}`,

    },
    {
      columnDef: 'Tokens',
      header: 'Tokens',
      cell: (element: Record<string, any>) => `${element['Tokens']}`,
      image : 'active-streams.png',
      isNumberAndImage : true,
    },
    {
      columnDef: 'Email',
      header: 'Email',
      cell: (element: Record<string, any>) => `${element['Email']}`
    } 
    ,{
      columnDef: 'Created',
      header: 'Created',
      cell: (element: Record<string, any>) => `${element['Created']}`,
    }   
    
  ];
}
