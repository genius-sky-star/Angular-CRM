import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StreamersComponent } from './streamers.component';

const routes: Routes = [
  {
    path:'',
    component:StreamersComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StreamersRoutingModule { }
