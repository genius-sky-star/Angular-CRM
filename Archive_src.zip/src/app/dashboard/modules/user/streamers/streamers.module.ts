import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { StreamersRoutingModule } from './streamers-routing.module';
import { StreamersComponent } from './streamers.component';


@NgModule({
  declarations: [
    StreamersComponent
  ],
  imports: [
    CommonModule,
    StreamersRoutingModule
  ]
})
export class StreamersModule { }
