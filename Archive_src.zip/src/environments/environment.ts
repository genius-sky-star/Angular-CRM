export const environment = {
  production: false,
  apiUrl: 'https://api.girlsgonegame.com',
  supabaseEmailRedirect: 'https://admin.girlsgonegame.com/login/redirect',
  supabaseUrl: 'https://qjampefwpiyygsmmnxug.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFqYW1wZWZ3cGl5eWdzbW1ueHVnIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODkwMjYwODQsImV4cCI6MjAwNDYwMjA4NH0.1GE78VVUlLD93G2x2RnkuRO1_TU6GzHBYRKIjBzn9vQ',
  mapboxKey: 'pk.eyJ1IjoiZ2lybHNnb25lZ2FtZSIsImEiOiJjbGtoaXhubTEwOTdoM3FwNG0yMXRhcTVmIn0.IFDywC-gorsR0FFvrWO1Xg'
};
