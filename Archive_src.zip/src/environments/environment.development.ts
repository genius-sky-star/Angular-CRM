export const environment = {
  production: false,
  apiUrl: 'https://localhost:3000/api',
  supabaseUrl: 'https://qjampefwpiyygsmmnxug.supabase.co',
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFqYW1wZWZ3cGl5eWdzbW1ueHVnIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODkwMjYwODQsImV4cCI6MjAwNDYwMjA4NH0.1GE78VVUlLD93G2x2RnkuRO1_TU6GzHBYRKIjBzn9vQ',
};
